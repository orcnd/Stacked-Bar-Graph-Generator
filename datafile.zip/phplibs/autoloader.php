<?php
require_once 'orcDatabase/orcDatabase.php';
require_once 'orcFrameworkMini/orcFrameworkMini.php';
