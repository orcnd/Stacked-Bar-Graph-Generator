$('#addDataSave').click(function () {
  $('#addCSVModal').modal('hide')
  data = formatData($('#csvData').val())
  drawChart(data)
  return true
})

function formatData(dataVirgin) {
  var dataLines = dataVirgin.split('\n')
  var rowLabels = []
  var datasets = []

  var backgroundColors = dataLines[0].split('\t')
  var borderColors = dataLines[1].split('\t')
  var textColors = dataLines[2].split('\t')
  var stacks = dataLines[3].split('\t')
  var columnLabels = dataLines[4].split('\t')

  for (var i = 1; i < columnLabels.length; i++) {
    datasets[i - 1] = {
      label: columnLabels[i],
      data: [],
      stack: stacks[i],
      backgroundColor: backgroundColors[i],
      borderColor: borderColors[i],
      color: textColors[i],
    }
  }

  for (var i = 5; i < dataLines.length; i++) {
    var line = dataLines[i].split('\t')
    rowLabels.push(line[0])
    for (var j = 1; j < line.length; j++) {
      datasets[j - 1].data.push(parseFloat(line[j]))
    }
  }

  return {
    labels: rowLabels,
    datasets: datasets,
  }
}

function drawChart(dataGiven) {
  const config = {
    type: 'bar',
    data: dataGiven,
    options: {
      responsive: true,
      tooltips: { enabled: false },
      events: [],
      interaction: {
        intersect: false,
      },
      scales: {
        x: {
          stacked: true,
        },
        y: {
          stacked: true,
          min: parseFloat($('#min').val()),
          max: parseFloat($('#max').val()),
          barStart: parseFloat($('#min').val()),
          barEnd: parseFloat($('#max').val()),
        },
      },
    },
  }

  const ctx = document.getElementById('myChart').getContext('2d')
  const myChart = new Chart(ctx, config)
}
