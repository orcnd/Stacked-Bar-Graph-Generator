<?php 
$xml = <<<'wadastatio23ngoddam2nrightye1a23'
.~ff]32et2a72n811{f61a?d15%6&36e2c,czpa71d8[1pd8&a}7>36af.fz~bqe%2cc2c?c{2cc3{a41g56a7uq;2a7f[>3y1f630-83*a42cc[2>f61?0d2!ccbte>o2cc,2cc&f<f3*2e2a-728_11,f61ad}15@6_36e2czc}a~71,d81dp8.?a736a{&f;f]b.e@2cc2cc&p36e_34dbvey36ge
wadastatio23ngoddam2nrightye1a23;
?>